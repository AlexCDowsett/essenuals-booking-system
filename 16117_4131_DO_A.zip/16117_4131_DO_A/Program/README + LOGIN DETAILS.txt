default login:
	Staff ID: 1
	password: ess19
------------------------------------------------------------------------------------------------
If you wish to view the database file (.db) without the Python program, use an external program.


I recommend DB Browser for SQLite, however any program able to open .db files should do.

	Download: https://sqlitebrowser.org/dl/


Please read the User Guide for more information about how to use and install this program.